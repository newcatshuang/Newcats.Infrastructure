﻿using System;

namespace Db.DbObject
{
    public class UniqueKey : PrimaryKey
    {
    }
}
