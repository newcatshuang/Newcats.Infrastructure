﻿using System;

namespace Db.DbObject
{
    public interface IDbObject
    {
        string ToString();
    }
}
