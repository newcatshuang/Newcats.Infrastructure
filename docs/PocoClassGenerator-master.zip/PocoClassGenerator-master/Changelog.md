### version 0.9.5
- [X] Support DataTable Generate POCO Class 

### version 0.9.4
- [X] Fix View Support 
  - [X] [When View using CommandBehavior.KeyInfo will get duplicate columns �P Issue #8](https://github.com/shps951023/PocoClassGenerator/issues/8)
  - [X] [Fix View Use BaseTableName Not ViewName �P Issue #7](https://github.com/shps951023/PocoClassGenerator/issues/7)

### version 0.9.3
- [X] Fix : Generate Class Name By Full Name To Avoid Not Using Problem
- [X] Fix : If table/view name contains white space then replace it by empty string

### version 0.9.2
- [X] Support Dapper Contrib
- [X] Support Generate Class Comment

### version 0.9.1
- [X]   Support current DataBase all tables and views generate POCO class code
- [X]   Support multiple RDBMS: `sqlserver`, `oracle`, `mysql`, `postgresql`
- [X]   Mini and faster (only in 5 seconds generate 100 tables code)
- [X]   Use appropriate dialect schema table SQL for each database query
